package model.agents.vegetaux;

import java.awt.Point;
import java.util.TreeSet;

import model.agents.Animal;
import model.agents.animaux.AbeilleDomestique;
import model.agents.animaux.AbeilleSolitaire;
import model.agents.animaux.Frelon;
import model.comportements.Hebergeur;

public class Arbre extends Vegetal implements Hebergeur{
	
	private TreeSet<Animal> population;

	public Arbre(Point point, double taille) {
		super(point);
		this.taille=taille;
	}

	private double taille = 1.0;
	private int nbHeberges = 0;
	
	@Override
	public boolean peutAccueillir(Animal a) {
		return (a instanceof AbeilleSolitaire || a instanceof Frelon)&&nbHeberges<getMaxHeberges();
	}

	private int getMaxHeberges() {
		return (int)(Math.pow(taille,2));
	}

	@Override
	public boolean accueillir(Animal a) {
		boolean ret = false;
		if(peutAccueillir(a)) {
			nbHeberges++;
			population.add(a);
			ret=true;
		}
		return ret;
	}

	@Override
	public void produire() {
		qteNectar += Math.pow(2, taille);		
	}

	@Override
	public void supprimer(Animal a) {
		nbHeberges--;
		population.remove(a);
	}

	@Override
	public Object clone() {
		// TODO Auto-generated method stub
		return new Arbre(getCoord(), taille);
	}

}
