package model.agents.animaux;

import java.awt.Point;

import model.agents.Agent;
import model.agents.Animal;
import model.agents.Etat;
import model.agents.Sexe;

public class FrelonEuropeen extends Frelon {
	
	public FrelonEuropeen(Sexe s, Point p) {
		super(s, p);
		proies.add(FrelonAsiatique.class);
	}
	
	

	// inutile avec la liste de proies à partir des collections
	@Override
	public void rencontrer(Agent a) {
		//penser à réutiliser l'existant
		super.rencontrer(a);
		
		if(a instanceof FrelonAsiatique) {
			Animal b = (Animal)a;
			this.setNiveauSante(Etat.EnDetresse);
			gestionProie(b);
		}

	}



	@Override
	public Object clone() {
		// TODO Auto-generated method stub
		return new FrelonEuropeen(getSexe(), new Point(getCoord().x, getCoord().y));
	}
	

}
