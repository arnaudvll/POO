package model.agents.animaux;

import java.awt.Point;

import model.agents.Sexe;

public class AbeilleSolitaire extends Abeille{

	public AbeilleSolitaire(Sexe s, Point p) {
		super(s, p);
	}

	@Override
	public Object clone() {
		// TODO Auto-generated method stub
		return new AbeilleSolitaire(getSexe(), new Point(getCoord().x, getCoord().y));
	}

}
