package model.world;

import java.util.Comparator;

import model.agents.Agent;

public class CoordComparator implements Comparator<Agent> {

	@Override
	public int compare(Agent o, Agent a) {
		int ret = 0;
		if (o.getCoord().x < a.getCoord().x) {
			ret = -1;
		}
		if (o.getCoord().x == a.getCoord().x) {
			if (o.getCoord().y <= a.getCoord().y) {
				ret = -1;
			}
			else if (o.getCoord().y > a.getCoord().y) {
				ret = 1;
			}
		}
		if (o.getCoord().x > a.getCoord().x) {
			ret = 1;
		}
		return ret;
	}
}
