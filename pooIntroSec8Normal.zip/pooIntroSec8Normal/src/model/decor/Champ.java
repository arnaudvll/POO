package model.decor;

import java.awt.Point;

public class Champ extends Decor {
	
	private boolean pesticide;

	public Champ(Point p) {
		super(p);
		// TODO Auto-generated constructor stub
	}

}
