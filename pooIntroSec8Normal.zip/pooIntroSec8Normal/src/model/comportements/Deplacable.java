package model.comportements;
/**
 * Elements qui peuvent être déplacer
 * @author bruno
 *
 */
public interface Deplacable {
	/**
	 * méthode invoquée pour réaliser un déplacement
	 */
	public void seDeplacer(boolean nuit);
}
