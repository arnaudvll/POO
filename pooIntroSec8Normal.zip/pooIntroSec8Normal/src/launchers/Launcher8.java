package launchers;

import java.awt.Point;
import java.util.HashSet;

import model.agents.Agent;
import model.agents.animaux.AbeilleSolitaire;
import model.world.Monde;
import model.agents.Sexe;

public class Launcher8 {

	public static void main(String[] args) {
		Monde m = new Monde(50);
		System.out.println(m);
		m.cycle();
		System.out.println(m);
		AbeilleSolitaire a = new AbeilleSolitaire(Sexe.Femelle, new Point(0,0)) ;
		System.out.println(m.gererRencontre(a));
	}

}
