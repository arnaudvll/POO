module POO {
	requires java.desktop;
}