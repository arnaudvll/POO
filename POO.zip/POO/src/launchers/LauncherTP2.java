package launchers;

import java.awt.Point;

import tp.model.agents.Abeille;
import tp.model.agents.Agent;
import tp.model.agents.Animal;
import tp.model.agents.Arbre;
import tp.model.agents.Frelon;
import tp.model.agents.Sexe;
import tp.model.agents.Varroa;


public class LauncherTP2 {
	
	public static void main(String [] args) {
		Abeille a = new Abeille(Sexe.Femelle, new Point(0,0));
		
		Varroa varro = new Varroa();
		
		System.out.println(a.getCoord());
		a.seDeplacer();
		System.out.println(a.getCoord());
		//QUESTION 4 dans 6.3.5
		
		//TODO
		//tester la hiérarchie d'agent
		
	}

}
