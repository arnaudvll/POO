package tp.model.agents;

import java.awt.Point;

public class AbeilleSolitaire extends Abeille {
	public AbeilleSolitaire(Sexe sexe, Point coord) {
		super(sexe, coord);
	} 
}
