package tp.model.agents;

import java.awt.Point;
import java.util.ArrayList;

public class Frelon extends Animal{
	protected ArrayList proies;
	
	public Frelon(Sexe sexe, Point coord) {
		super(sexe, coord);
	}
	
	public void rencontrer(Agent a) {
		
	}
	
	protected void gestionProie(Animal a) {
		
	}
	
	protected void maj() {
		
	}
	
	protected void seNourrir() {
		
	}
}
