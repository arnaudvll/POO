package tp.model.agents;

public class Varroa extends Animal {
	public void rencontrer(Agent a) {
		
	}
	
	protected void maj() {
		
	}
	
	protected void seNourrir() {
		
	}
	
	public void seDeplacer() {
		
	}
}
