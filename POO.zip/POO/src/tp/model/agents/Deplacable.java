package tp.model.agents;

public interface Deplacable {
	public void seDeplacer();
}
