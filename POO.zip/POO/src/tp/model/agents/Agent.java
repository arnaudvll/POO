package tp.model.agents;

import java.awt.Point;

public class Agent {

	private static int currentId = 0;
	/** identifiant unique de l'animal*/
	private int id;
	/** age en unit� de temps*/
	protected int age;
	/** position sur la carte*/
	protected Point coord;
	protected boolean faim;

	public Agent(Point coord) {
		super(); //ajout auto par java normalement (cr�e un object)
		this.id = Animal.getUniqueId();
		this.age = 0;
		this.coord = coord;
		this.faim = false;
	}
	
	public Agent() {
		this(new Point(0,0));
	}
	
	/**
	 * Renvoie un identifiant unique non encore utilisé
	 * @return un identifiant entier unique d'animal
	 */
	protected static int getUniqueId() {
		currentId++;
		return (currentId - 1);
	}

	/** Retourne l'age d'un animal */
	public int getAge() { 
		return this.age;
	}

	/** Modifie l'age d'un animal avec l'age passé en paramètre */
	public void setAge(int new_age) {
		if (new_age > this.age) {
			this.age = new_age;
		}
	}

	/** Retourne l'id d'un animal */
	public int getId() {
		return this.id;
	}

	/** Retourne les coordonnées d'un animal */
	public Point getCoord() {
		Point coord2 = new Point(this.coord);
		return coord2;
	}

	/** Fait vieillir un animal d'un an */
	public void vieillir() {
		//fait vieillir l'animal d'une unit� de temps
		//une bonne mani�re de faire, une moins bonne...
		this.age++;
	}



}