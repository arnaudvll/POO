package tp.model.agents;

import java.awt.Point;

public class FrelonEuropeen extends Frelon {
	public FrelonEuropeen(Sexe sexe, Point coord) {
		super(sexe, coord);
	}
}
