package tp.model.agents;

public class Vegetal {
	protected int qteNectar;
	
	public void produire() {
		
	}
	
	public void rencontrer(Agent a) {
		
	}
	
	protected void maj() {
		
	}
	
	protected void seNourrir() {
		
	}
	
	public int getPortionNectar() {
		
	}
}
