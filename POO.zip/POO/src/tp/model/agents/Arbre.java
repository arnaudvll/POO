package tp.model.agents;

public class Arbre extends Vegetal {
	private double taille;
	private int nbHeberges;
	
	public boolean peutAccueillir(Animal a) {
		if ((a instanceof Frelon) && (nbHeberges <= taille)) {
			return true;
		}
		return false;
	}
	
	private int getMaxHeberges() {
		
	}
	
	public boolean accueillir(Animal a) {
		if (peutAccueillir(a) == true) {
			nbHeberges++;
			return true;
		}
		return false;
	}
	
	public void produire() {
		
	}
}
