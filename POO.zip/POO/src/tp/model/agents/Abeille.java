package tp.model.agents;

import java.awt.Point;

import tp.model.comportements.Hebergeur;

public class Abeille extends Animal implements Hebergeur {
	private boolean parasite;
	private int qteMiel;
	private int qteMax;
	
	public Abeille(Sexe sexe, Point coord) {
		super(sexe, coord);
	}
	
	public void rencontrer(Agent a) {
		
	}
	
	@Override
	public boolean peutAccueillir(Animal a) {
		if ((parasite == false) && (a instanceof Varroa)) {
			return true;
		}
		return false;
	}
	
	@Override
	public boolean accueillir(Animal a) {
		if (peutAccueillir(a) == true) {
			parasite = true;
			return true;
		}
		return false;
	}
	
	protected void maj() {
		
	}
	
	protected void seNourrir() {
		
	}
}