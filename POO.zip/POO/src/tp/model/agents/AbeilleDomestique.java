package tp.model.agents;

import java.awt.Point;

public class AbeilleDomestique extends Abeille {
	public AbeilleDomestique(Sexe sexe, Point coord) {
		super(sexe, coord);
	}
	
}
