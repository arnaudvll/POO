package tp.model.agents;

public class Fleur {
	public void produire() {
		
	}
}
