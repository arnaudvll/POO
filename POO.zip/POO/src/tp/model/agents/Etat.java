package tp.model.agents;

public enum Etat {
	PleineForme, EnForme, Normal, EnDifficulte, EnDetresse, Mourant
}
