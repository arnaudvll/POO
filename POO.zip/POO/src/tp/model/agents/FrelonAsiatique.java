package tp.model.agents;

import java.awt.Point;

public class FrelonAsiatique extends Frelon {
	public FrelonAsiatique(Sexe sexe, Point coord) {
		super(sexe, coord);
	}
}
