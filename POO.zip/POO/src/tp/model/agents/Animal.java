package tp.model.agents;

import java.awt.Point;


/**
 * Cette classe mod�lise un Animal dans la simulation
 * @author bruno
 *
 */

public class Animal extends Agent {
	/** �tat de sant� de l'animal */
	private Etat etat = Etat.Normal;
	private Sexe sexe;
	
	/* 
	 * constructeurs 
	 */
	
	/** Cette méthode crée un objet de type Animal avec un sexe de type Sexe et des coordonnées de type Point */
	public Animal(Sexe sexe, Point coord) { 
		super(coord); 
		this.sexe=sexe;
	}
	
	/** Cette méthode crée un objet de type Animal avec un sexe de type Sexe et des coordonnées (0,0) */
	public Animal(Sexe sexe) { 
		this(sexe, new Point(0,0));
		/* cr�e un animal avec le sexe pass� en param�tre, � la position (0;0), d'�ge 0 et lui attribue un id unique
		 * une bonne mani�re de faire 
		 * en utilisant ce qui existe d�j�, une moins bonne
		 */
	}
	
	/** Cette méthode crée un objet de type Animal avec un sexe femelle et des coordonnées (0,0) */
	public Animal() {
		this(Sexe.Femelle, new Point(0,0));
		/* cr�e un animal de sexe femelle, � la position (0;0), d'�ge 0 et lui attribue un id unique
		 * une bonne mani�re de faire 
		 * en utilisant ce qui existe d�j�, une moins bonne
		 */
	}
	
	/*
	 *  Accesseurs et mutateurs
	 */
	
	/** Retourne le sexe d'un animal */
	public Sexe getSexe() {
		return this.sexe;
	}
	
	/** Retourne l'état d'un animal */
	public Etat getEtat() {
		return this.etat;
	}
	
	
	
	
	/*
	 * Red�finitions de m�thodes d'object
	 */
	
	/** Redéfinition de la méthode toString */
	public String toString() {
		String ret = this.getClass().getSimpleName() + this.getId() + " (" + this.getSexe() + " (" + this.getCoord().x + ';' + this.getCoord().y + "))";
		return ret;
	}
	
	/** Redéfinition de la méthode equals */
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animal other = (Animal) obj;
		return age == other.age && etat == other.etat && sexe == other.sexe;
	}
	

	/* 
	 * comportements d'instance
	 */
	
	/** Déplace un animal de 1 unité dans n'importe quelle direction */
	public void seDeplacer() {
		//TODO utiliser Math.random() pour choisir une direction de d�placement
		int dx = (int) Math.round(2 * Math.random() -1);
		int dy = (int) Math.round(2 * Math.random() -1);
		this.coord.x += dx;
		this.coord.y += dy;
	}
	
	public void rencontrer(Animal a) {
		//TODO
	}
	
	public static void main(String args[]) {
		//tests unitaires de la classe Animal
		//TODO d�commentez les lignes pour approfondir le test unitaire
		//compl�tez la m�thode pour tester les nouvelles fonctionnalit�s que vous allez impl�menter
		Animal a = new Animal();
		Animal b = new Animal(Sexe.Male);
		Animal c = new Animal(Sexe.Assexue);
		Animal d = new Animal(Sexe.Femelle,new Point(25,30));
		Animal e = new Animal(Sexe.Femelle,new Point(25,30));
		Animal f = new Animal(Sexe.Femelle,new Point(25,30));
		
		/*
		 * les lignes suivantes doivent afficher � terme: NomDeLaClasse n° id_animal(sexe, (position x; position y)).
		 * ex: 28 (FEMELLE, (25;30))
		 */
		System.out.println("*** Animaux cr��s: **********");
		System.out.println(a);
		System.out.println(a.toString());
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		
		System.out.println("*** Getters et setters **********");
		
		System.out.println(d.getSexe());
		Sexe ss = d.getSexe();
		ss=Sexe.Male;
		System.out.println(d.getSexe());
		
		//les lignes suivantes devraient afficher la m�me chose....
		System.out.println(d.getCoord());
		Point pt = d.getCoord();
		pt.x=50;
		System.out.println(d.getCoord());
		
		
		//TODO ajoutez vos propres tests de getters et setters
		System.out.println(d.getAge());
		d.setAge(5);
		System.out.println(d.getAge());
		
		//TODO test vieillir
		d.vieillir();
		System.out.println(d.getAge());
		
		//TODO test seDeplacer
		System.out.println(d.getCoord());
		d.seDeplacer();
		System.out.println(d.getCoord());
		
		//TODO test id
		System.out.println(a.getId());
		System.out.println(c.getId());
		
		
		/*
		 * Test comparaison
		 */
		System.out.println(e==f);
		System.out.println(e.equals(f));
		System.out.println("Bonjour"=="Bonjour");
		System.out.println("Bonjour".equals("Bonjour"));
		
	}
}
